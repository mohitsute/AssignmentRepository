﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter id");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int id))
            {
                Console.WriteLine("enter name");
                input = Console.ReadLine();
                if (!string.IsNullOrEmpty(input))
                {
                    string name = input;
                    Console.WriteLine("enter address");
                    input = Console.ReadLine();
                    if (!string.IsNullOrEmpty(input))
                    {
                        string address = input;
                        Console.WriteLine("enter city");
                        input = Console.ReadLine();
                        if (!string.IsNullOrEmpty(input))
                        {
                            string city = input;
                            Console.WriteLine("enter department");
                            input = Console.ReadLine();
                            if (!string.IsNullOrEmpty(input))
                            {
                                string department = input;
                                Console.WriteLine("enter salary");
                                input = Console.ReadLine();
                                if (double.TryParse(input, out double salary))
                                {
                                    Employee newEmployee = new Employee(id, name, address,
                                        city, department, salary);
                                    newEmployee.Display();
                                }
                                else
                                {
                                    Console.WriteLine("invalid salary");
                                }
                            }
                            else
                            {
                                Console.WriteLine("invalid department");
                            }
                        }
                        else
                        {
                            Console.WriteLine("invalid city");
                        }
                    }
                    else
                    {
                        Console.WriteLine("invalid address");
                    }
                }
                else
                {
                    Console.WriteLine("invalid name");
                }
            }
            else
            {
                Console.WriteLine("invalid id");
            }
            Console.Read();
        }
    }
}
