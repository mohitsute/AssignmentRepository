﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLab1
{
    class Employee
    {
        int id;
        string name, address, city, department;
        double salary;

        public Employee(int id, string name, 
            string address, string city, 
            string department, double salary)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.city = city;
            this.department = department;
            this.salary = salary;
        }

        public void Display()
        {
            Console.WriteLine($"Id: {id}, Name: {name}, address: " + 
                $"{address}, city: {city}, department: {department}, " + 
                $"salary: {salary}");
        }
    }
}
